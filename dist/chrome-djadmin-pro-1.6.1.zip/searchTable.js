(()=>{var c=null;function i(e){var n=e.querySelector(".section").innerText,a=[],l=e.querySelectorAll("tr th a");for(let o=0;o<l.length;o++){let t=l[o].innerText,r=l[o].getAttribute("href");a.push({schema:n,name:t,path:r})}return a}function s(){for(var e=[],n=document.querySelectorAll("#nav-sidebar table,.dashboard #content-main table"),a=0;a<n.length;a++)e=e.concat(i(n[a]));return e}function d(){let e=document.createElement("dialog"),n=s();e.className="search",e.innerHTML=`
    <div class="close-container">
      <button class="close">x</button>
    </div>
    <div id="modal-content" style="height: 340px">
      <div class="filter-select">
      <select name="table-columns" id="table-list" class="wide">
      ${n.map(l=>`<option value="${l.path}">${l.name} - ${l.schema}</option>`).join("")}
      </select>
    </div>
  `,document.body.appendChild(e);let a=document.querySelector("dialog.search");a.querySelector("button.close").addEventListener("click",()=>{a.close()}),c=new NiceSelect(document.getElementById("table-list"),{searchable:!0,onChanged:function(l,o){if(o.ctrlKey||o.metaKey){let t=document.createElement("a");t.href=window.location.href,t.pathname=l[0],t.target="_blank",document.body.appendChild(t),t.click(),a.close()}else{let t=document.createElement("a");t.href=window.location.href,t.pathname=l[0],t.search="",window.location.href=t.href,a.close()}}})}function u(){document.addEventListener("keydown",function(e){(e.ctrlKey&&e.key==="J"||e.metaKey&&e.shiftKey&&e.key==="p")&&(document.querySelector("dialog.search").showModal(),setTimeout(()=>{c.focus()},300))})}d();u();})();
